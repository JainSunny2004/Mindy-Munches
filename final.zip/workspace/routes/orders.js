const express = require('express');
const { body } = require('express-validator');
const orderController = require('../controllers/orderController');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// Validation rules
const createOrderValidation = [
  body('shippingAddress.name')
    .trim()
    .notEmpty()
    .withMessage('Name is required'),
  body('shippingAddress.phone')
    .trim()
    .notEmpty()
    .withMessage('Phone is required'),
  body('shippingAddress.street')
    .trim()
    .notEmpty()
    .withMessage('Street address is required'),
  body('shippingAddress.city')
    .trim()
    .notEmpty()
    .withMessage('City is required'),
  body('shippingAddress.state')
    .trim()
    .notEmpty()
    .withMessage('State is required'),
  body('shippingAddress.zipCode')
    .trim()
    .notEmpty()
    .withMessage('ZIP code is required'),
  body('paymentMethod')
    .isIn(['cod', 'card', 'upi', 'netbanking'])
    .withMessage('Invalid payment method')
];

// User routes (require authentication)
router.use(authenticate);

router.post('/', createOrderValidation, orderController.createOrder);
router.get('/my-orders', orderController.getUserOrders);
router.get('/:id', orderController.getOrderById);
router.post('/:id/cancel', orderController.cancelOrder);

// Admin routes
router.get('/', requireAdmin, orderController.getAllOrders);
router.patch('/:id/status', requireAdmin, orderController.updateOrderStatus);
router.get('/analytics/summary', requireAdmin, orderController.getOrderAnalytics);

module.exports = router;